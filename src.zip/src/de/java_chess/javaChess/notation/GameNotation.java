/*
  GameNotation - This interace defines the functionality to notate a 
                 entire game.

  Copyright (C) 2003 The Java-Chess team <info@java-chess.de>

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/ 

package de.java_chess.javaChess.notation;


/**
 * This interface defines the functionality to notate a entire game.
 */
public interface GameNotation {


    // Methods

    /**
     * Reset the game notation for a new game.
     */
    public void reset();

    /**
     * Get the notation for a given move and piece color.
     *
     * @param moveIndex The index of the move.
     * @param boolean white Flag to indicate if the color is white.
     *
     * @return The notation for a given move and color.
     */
    String getMove( int moveIndex, boolean white);

    /**
     * Add a new ply with it's notation.
     *
     * @param plyNotation The notation of the new ply.
     */
    public void addPly( PlyNotation plyNotation);

    /**
     * Get a ply with a given index.
     *
     * @param index The index of the ply.
     */
    public PlyNotation getPlyNotation( int index);

    /**
     * Get the number of plies in this notation.
     *
     * @return The number of plies.
     */
    public int size();

    /**
     * Get some extended PGN compatible info on the game.
     *
     * @return Extended PGN compatible info on the game.
     */
    String getPGNheader();

    /**
     * Get the entire game as a string.
     *
     * @return The entire game as a string.
     */
    String toString();

    /**
     * Get some info on a player.
     *
     * @return Some info on a player.
     */
    String getPlayerInfo( boolean white);

    /**
     * Set the info on a player.
     *
     * @param playerInfo The player info.
     * @param white Flag to indicate, if it's the player 
     *              with the white pieces.
     */
    void setPlayerInfo( String playerInfo, boolean white);

    /**
     * Get the info on the used opening.
     *
     * @return The name of the used opening.
     */
    String getOpeningInfo();

    /**
     * Set the info on the used opening.
     *
     * @param name The name of the opening.
     */
    void setOpeningInfo( String name);
}
